import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the SharedProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SharedProvider {
	property1: string;
	property2: string;
	property3: string;
	property4: string;

  constructor(public http: HttpClient) {
  }
	 
	setCountryID(data) {
		this.property1 = data;
	}
	
	getCountryID(): string{
		return this.property1;
	}
	
	setMinAge(data) {
		this.property2 = data;
	}
	
	getMinAge(): string{
		return this.property2;
	}
	
	setMaxAge(data) {
		this.property3 = data;
	}
	
	getMaxAge(): string{
		return this.property3;
	}
	
	setCountryName(data) {
		this.property4 = data;
	}
	
	getCountryName(): string{
		return this.property4;
	}
}
