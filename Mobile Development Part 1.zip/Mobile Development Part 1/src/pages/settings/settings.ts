import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SharedProvider } from '../../providers/shared/shared';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {

  countryID: string;
  
  minAge: string;
  maxAge: string;
  
  countryName: string;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, private shared: SharedProvider,  public http: HttpClient) {
  }

  ionViewWillLeave() {
	this.shared.setCountryName(this.countryName);
  } 
  
  ionViewWillEnter() {
	this.readTeamData();
  }
  
  readTeamData() {
	this.countryID = this.shared.getCountryID();
	this.minAge = this.shared.getMinAge();
	this.maxAge = this.shared.getMaxAge();
  }

  saveSettings() {
	if(this.countryID == null) {
		alert("Please enter a Country ID");
	}	
	this.shared.setCountryID(this.countryID);
	if (this.minAge != "") {
		this.shared.setMinAge(this.minAge);
	};
	if (this.maxAge != "") {
		this.shared.setMaxAge(this.maxAge);
	};
	this.navCtrl.pop();
  }
  
  closePage() {
	this.navCtrl.pop();
  }
  
  getCountry(id): Observable<any> {
	return this.http.get("https://app.sportdataapi.com/api/v1/soccer/countries/" + id +"?apikey=ae33bfa0-79af-11ed-8669-09d92e0dd068");
  }
}
