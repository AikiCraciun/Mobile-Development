import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { QuoteProvider } from '../../providers/quote/quote';
import { SettingsPage } from '../settings/settings';
import { SharedProvider } from '../../providers/shared/shared';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit{
	author: string;
	tags: string[];
	content: string;
	
	minAge = "";
	maxAge = "";
	countryID;

	//countryName;
	country_code;

	data: Object;
	countryName;
	countryFlag;
	
	src = "";
	
	players: Object = {};
	
	htmlForTable: string;

  constructor(public navCtrl: NavController, public http: HttpClient, private quoteProvider: QuoteProvider, private shared: SharedProvider) {

  }
  
  ionViewDidLoad() {
	this.quoteProvider.getQuote().subscribe(data => {
		this.author = data.author;
		this.tags = data.tags;
		this.content = data.content;
	})
	this.countryID = "BLANK"
  }
  
  ngOnInit() {
	this.countryID = "BLANK";
	this.countryName= "BLANK";
  }
  
  ionViewWillEnter() {
	this.readTeamData();
	
	if (this.countryID  != undefined) {
	this.getCountry(this.countryID).subscribe(data => {
		this.data = data;
		this.countryName = data.data.name;
		this.countryFlag = data.data.country_code;
		console.log("Country Name is " + this.countryName);
		console.log("Country Code is " + this.countryFlag);
		
		
		this.src = "https://flagsapi.com/" + this.countryFlag.toUpperCase()+ "/shiny/64.png";
		console.log("src is " + this.src);
		}) 
		
		
		if (this.countryID  != undefined && this.maxAge != undefined && this.minAge == undefined) {
			this.getPlayersMaxAge(this.countryID, this.maxAge).subscribe(data => {
			this.players = data.data;
			console.log(this.players);
			this.introduceHTMLTable(this.players);
			})
		}
		
		if (this.countryID  != undefined && this.maxAge == undefined && this.minAge != undefined) {
			this.getPlayersMinAge(this.countryID, this.minAge).subscribe(data => {
			this.players = data.data;
			console.log(this.players);
			this.introduceHTMLTable(this.players);
			})
		}
		
		if (this.countryID  != undefined && this.minAge != undefined && this.maxAge != undefined) {
			this.getPlayersBetweenAge(this.countryID, this.minAge, this.maxAge).subscribe(data => {
			this.players = data.data;
			console.log(this.players);
			//console.log("type of " +this.players.type);
			this.introduceHTMLTable(this.players);
			})
		}
	}
	
	console.log("CountryID is " + this.countryID);
	console.log("minAge is " + this.minAge);
	console.log("maxAge is " + this.maxAge);
	console.log("Country Name is " + this.countryName);
	
	
  }
  
  public openSettings() {
	this.navCtrl.push(SettingsPage)
  }
  
  getCountry(id): Observable<any> {
	return this.http.get("https://app.sportdataapi.com/api/v1/soccer/countries/" + id +"?apikey=ae33bfa0-79af-11ed-8669-09d92e0dd068");
  }
  
   getPlayersMaxAge(id, maxAge): Observable<any> {
	return this.http.get("https://app.sportdataapi.com/api/v1/soccer/players?apikey=ae33bfa0-79af-11ed-8669-09d92e0dd068&country_id=" + id + "&max_age="+ maxAge + '"');
  }
  
  getPlayersMinAge(id, minAge): Observable<any> {
	return this.http.get("https://app.sportdataapi.com/api/v1/soccer/players?apikey=ae33bfa0-79af-11ed-8669-09d92e0dd068&country_id=" + id + "&min_age="+ (minAge - 1) + '"');
  }
  
  getPlayersBetweenAge(id, minAge, maxAge): Observable<any> {
	return this.http.get("https://app.sportdataapi.com/api/v1/soccer/players?apikey=ae33bfa0-79af-11ed-8669-09d92e0dd068&country_id=" + id + "&max_age="+ maxAge + "&min_age=" + (minAge - 1) + '"');
  }

  readTeamData() {
	this.countryID = this.shared.getCountryID();
	this.minAge = this.shared.getMinAge();
	this.maxAge = this.shared.getMaxAge();
  }
  
  //extractPlayersInfo(arrayObjects: Object[]) {}
  
  introduceHTMLTable(arrayObject: any) {
  
	let htmlForTable: string = "<table><tr><th>First Name</th><th>Surname</th><th>Age</th><th>Height</th></tr>";
	
	for (let i of arrayObject) {
		htmlForTable += "<tr><td>" + i.firstname + "</td><td>" + i.lastname + "</td><td>" + i.age + "</td><td>" + i.height + "</td></tr>";
	}
	htmlForTable += "</table>";
	
	this.htmlForTable = htmlForTable;
	
	document.getElementById("emp").innerHTML = this.htmlForTable;
  }
}
